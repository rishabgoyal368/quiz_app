<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AdminController extends Controller
{
    public function login_page(){
    	return view('Admin.login');
    }

    public function forgot_password(){
    	return view('Admin.forgot_password');
    }
}
