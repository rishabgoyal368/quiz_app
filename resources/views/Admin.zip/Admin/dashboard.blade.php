@extends('Admin.layout.master')
@section('title','Home')
@section('content')

    <div class="c-sidebar c-sidebar-dark c-sidebar-fixed c-sidebar-lg-show" id="sidebar">



      @include('Admin.common.header')

      <div class="c-body">

        <main class="c-main">

          @yield('content') 

        </main>
        @include('Admin.common.footer')
      </div>
    </div>

@endsection